package br.com.fecaf.model;

import java.util.Scanner;

public class Circulo {
    public double raio, area, perimetro;

    Scanner scanner = new Scanner(System.in);

    public boolean cadastrarCirculo() {
        System.out.println("/********************/");
        System.out.println("/*Cadastro Circulo*/");
        System.out.println("/*******************/");
        System.out.println("Informe o raio do circiulo: ");
        raio = scanner.nextDouble();
        System.out.println("Circulo Cadastrado com Sucesso !");
        System.out.println("/************************/");
        return true;
    }


    public void calcularArea(){
        System.out.println("/* Calculando Area */");

        area = Math.PI * Math.pow(raio, 2);

        System.out.println("A área é: " + area);
    }

    public void calcularPerimetro(){
        System.out.println("/ *Calculando o perimetro* /");

        perimetro = 2 * Math.PI * raio;
    }

}
