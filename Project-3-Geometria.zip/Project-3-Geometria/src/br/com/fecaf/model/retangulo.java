package br.com.fecaf.model;

import java.util.Scanner;

public class retangulo {
    public double lado1, lado2, area, perimetro;

    Scanner scanner = new Scanner(System.in);

    public void cadastrarRetangulo() {
        System.out.println("/*******************/");
        System.out.println("/** Cadastrar Retangulo**/");
        System.out.println("/*******************/");
        System.out.println("Informe o lado 1: ");
        lado1 = scanner.nextDouble();
        System.out.println("Informe o lado 2: ");
        lado2 = scanner.nextDouble();
        System.out.println("Retangulo Cadastrado com Sucesso !");
        System.out.println("/******************************/");
    }

    public void  calcularArea() {
        System.out.println("/* Calculando Area */");
        area = lado1 * lado2;
        System.out.println("A area é: " + area);
    }

    public void calcularPerimetro () {
        System.out.println("*Calculado Perimetro*");
        perimetro = lado1 * 2 + lado2 * 2;
        System.out.println("O perimetro é: " + perimetro);
    }

}
