package br.com.fecaf.model;

import java.util.Scanner;

public class Triangulo {
    // Esses são os atributos do triangulo !!!
    public double ladoA, ladoB, ladoC;


    // Instanciando a Biblioteca Scanner para o cálculo
    Scanner scanner = new Scanner(System.in);


    // Cadastrando o triangulo no sistema
    public void cadastrarTriangulo() {
        System.out.println("//");
        System.out.println("/*      Cadastro Triangulo      */");
        System.out.println("//");
        System.out.print("Informe um dos lados do Triângulo: ");
        ladoA = scanner.nextDouble();
        System.out.println("Informe outro lado do Triângulo: ");
        ladoB = scanner.nextDouble();
        System.out.println("Informe o último lado do Triângulo: ");
        ladoC = scanner.nextDouble();
        System.out.println("Triângulo Cadastrado com Sucesso !");
        System.out.println("//");
    }


    public void classificarTriangulo() {
        System.out.println("******** Classificando Triangulo ********");


        //Aqui está verificando se o triângulo criado é retângulo

        if (ladoC > ladoB && ladoC > ladoA) { //Aqui ele está verificando se o lado é maior (hipotenusa)
            if (ladoC * ladoC == ladoB * ladoB + ladoA * ladoA) { //Usando o Teorema de Pitágoras como base para o cálculo
                System.out.println("Esse Triângulo é Retângulo");
            } else {
                System.out.println("Esse Triângulo não é Retângulo");
            }
        } else if (ladoA > ladoB && ladoA > ladoC) { //Aqui ele está verificando se o lado A é o maior lado do triângulo (hipotenusa)
            if (ladoA * ladoA == ladoB * ladoB + ladoC * ladoC) {
                System.out.println("Esse Triângulo é Retangulo");
            } else {
                System.out.println("Esse Triângulo não é Retangulo");
            }
        } else if (ladoB > ladoA && ladoB > ladoC) { //Aqui ele está verifica se o lado B é o maior lado do triângulo (hipotenusa)
            if (ladoB * ladoB == ladoA * ladoA + ladoB * ladoB) {
                System.out.println("Esse Triângulo é Retangulo");
            } else {
                System.out.println("Esse Triângulo não é Retangulo");
            }
        } else {
            System.out.println("Esse Triângulo não é Retangulo");
        }


    }
}
