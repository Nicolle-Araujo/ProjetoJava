package br.com.fecaf.controller;

import br.com.fecaf.model.Circulo;
import br.com.fecaf.model.Triangulo;
import br.com.fecaf.model.retangulo;

import java.util.Scanner;

public class Menu {

    Scanner scanner = new Scanner(System.in);

    public void executarMenu() {

        boolean exit = false;

        while (!exit) {
            System.out.println("/***********************/");
            System.out.println("/* Geometria */");
            System.out.println("/**********************/");
            System.out.println("/* 1 - Circulo */");
            System.out.println("/* 2 - Retangulo*/");
            System.out.println("/* 3 - Triangulo */");
            System.out.println("/* 4 - Sair */");
            System.out.println("/**********************/");

            System.out.println("Informe a posicão desejada: ");
            int optionUser = scanner.nextInt();

            switch (optionUser) {
                case 1:

                    boolean exitCirculo = false;

                    Circulo circulo = new Circulo();

                    boolean validarCadastro = false;


                    while (!exitCirculo) {

                        System.out.println("/*************/");
                        System.out.println("* Circulo *");
                        System.out.println("/*************/");
                        System.out.println("/* 1 - Cadastrar circulo */");
                        System.out.println("/* 2 - Calcular Area */");
                        System.out.println("/* 3 - Calcular Perímetro */");
                        System.out.println("/* 4 - Sair */");
                        System.out.println("/*************/");
                        System.out.println("Informe a opcão desejada: ");

                        int optionCirculo = scanner.nextInt();


                        switch (optionCirculo) {
                            case 1:
                                validarCadastro = circulo.cadastrarCirculo();
                                break;
                            case 2:
                                if (validarCadastro) {
                                    circulo.calcularArea();
                                } else {
                                    System.out.println("Cadastre um círculo");
                                }
                                break;
                            case 3:
                                if (validarCadastro) {
                                    circulo.calcularPerimetro();
                                } else {
                                    System.out.println("Cadastre um círculo");
                                }
                                circulo.calcularPerimetro();
                                break;
                            case 4:
                                System.out.println("Saindo do circulo ...");
                                exitCirculo = true;
                                break;
                            default:
                        }
                    }

                    break;
                case 2:
                    boolean exitRetangulo = false;

                    retangulo retangulo = new retangulo();

                    boolean validarRetangulo = true;

                    int optionRetangulo = scanner.nextInt();

                    while (!exitRetangulo) {

                        System.out.println("/*************/");
                        System.out.println("* Retangulo *");
                        System.out.println("/*************/");
                        System.out.println("/* 1 - Cadastrar Retangulo */");
                        System.out.println("/* 2 - Calcular Area */");
                        System.out.println("/* 3 - Calcular Perímetro */");
                        System.out.println("/* 4 - Sair */");
                        System.out.println("/*************/");
                        System.out.println("Informe a opcão desejada: ");


                        switch (optionRetangulo) {
                            case 1:
                                retangulo.cadastrarRetangulo();
                                break;
                            case 2:
                                if (validarRetangulo) {
                                    retangulo.calcularArea();
                                } else {
                                    System.out.println("Cadastre um retangulo");
                                }
                                break;
                            case 3:
                                if (validarRetangulo) {
                                    retangulo.calcularPerimetro();
                                } else {
                                    System.out.println("Cadastre um retangulo");
                                }
                                retangulo.calcularPerimetro();
                                break;
                            case 4:
                                System.out.println("Saindo do retangulo ...");
                                exitRetangulo = true;
                                break;
                            default:
                        }
                    }
                    case 3:
                        boolean exitTriangulo = false;


                        Triangulo triangulo = new Triangulo();


                        boolean validaTriangulo = true;


                        while (!exitTriangulo) {


                            System.out.println("//");
                            System.out.println("/****     Triangulo      ****/");
                            System.out.println("//");
                            System.out.println("/* 1 - Cadastrar Triangulo  */");
                            System.out.println("/* 2 - Classificar Triângulo      */");
                            System.out.println("/* 3 - Identificar Padrão 345 */");
                            System.out.println("/* 4 - Sair               */");
                            System.out.println("//");
                            System.out.print("Informe a opção desejada: ");


                            int optionTriangulo = scanner.nextInt();


                            switch (optionTriangulo) {


                                    case 1:
                                        triangulo.cadastrarTriangulo();
                                        break;
                                    case 2:
                                        if (validaTriangulo) {
                                            triangulo.classificarTriangulo();
                                        } else {
                                            System.out.println("Cadastre o Triângulo");
                                        }
                                        break;
                                }
                            }
                        case 4:
                            System.out.println("Escolheu 4");
                            exit = true;
                            break;
                        default:
                            System.out.println("Escolha uma opcão válida");
                    }

//            if (optionUser == 1) {
//                System.out.println("Escolheu 1");
//            } else if (optionUser == 2) {
//                System.out.println("Escolheu 2");
//            } else if (optionUser == 3) {
//                System.out.println("Escolheu 3");
//            } else if (optionUser == 4) {
//                System.out.println("Saindo.....");
//                exit = true;
//            } else {
//                System.out.println("Opcão Inválida!!!!!");
//            }
            }

        }
    }

